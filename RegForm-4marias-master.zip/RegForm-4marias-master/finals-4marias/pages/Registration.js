import Form from "../components/Form";

export default function Registration() {
    return(
        <div>
            <Form/>
        </div>
    );
}
